import { Student, AttendanceRecord } from '../types/student';

const STUDENTS_KEY = 'attendance_students';
const ATTENDANCE_KEY = 'attendance_records';

export const saveStudents = (students: Student[]): void => {
  localStorage.setItem(STUDENTS_KEY, JSON.stringify(students));
};

export const loadStudents = (): Student[] => {
  const data = localStorage.getItem(STUDENTS_KEY);
  return data ? JSON.parse(data) : [];
};

export const saveAttendanceRecord = (record: AttendanceRecord): void => {
  const records = loadAttendanceRecords();
  records.push(record);
  localStorage.setItem(ATTENDANCE_KEY, JSON.stringify(records));
};

export const loadAttendanceRecords = (): AttendanceRecord[] => {
  const data = localStorage.getItem(ATTENDANCE_KEY);
  return data ? JSON.parse(data) : [];
};

export const hasAttendanceToday = (studentId: string): boolean => {
  const records = loadAttendanceRecords();
  const today = new Date().toDateString();
  
  return records.some(record => 
    record.studentId === studentId && 
    new Date(record.timestamp).toDateString() === today
  );
};

export const exportToCSV = (records: AttendanceRecord[]): void => {
  const headers = ['Student ID', 'Student Name', 'Date', 'Time'];
  const csvContent = [
    headers.join(','),
    ...records.map(record => 
      [record.studentId, record.studentName, record.date, record.time].join(',')
    )
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv' });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'attendance.csv';
  link.click();
  window.URL.revokeObjectURL(url);
};
import React, { useState, useEffect } from 'react';
import { GraduationCap } from 'lucide-react';
import { StudentRegistration } from './components/StudentRegistration';
import { AttendanceTracker } from './components/AttendanceTracker';
import { AttendanceReports } from './components/AttendanceReports';
import { Student } from './types/student';
import { saveStudents, loadStudents } from './utils/storage';

type Tab = 'register' | 'track' | 'reports';

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('register');
  const [students, setStudents] = useState<Student[]>([]);

  useEffect(() => {
    const loadedStudents = loadStudents();
    setStudents(loadedStudents);
  }, []);

  const handleStudentRegistered = (student: Student) => {
    const updatedStudents = [...students, student];
    setStudents(updatedStudents);
    saveStudents(updatedStudents);
    alert(`Student ${student.name} registered successfully!`);
  };

  const tabConfig = [
    { id: 'register' as Tab, label: 'Register Student', color: 'blue' },
    { id: 'track' as Tab, label: 'Track Attendance', color: 'green' },
    { id: 'reports' as Tab, label: 'View Reports', color: 'purple' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <GraduationCap className="w-8 h-8 text-blue-600" />
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                Student Attendance System
              </h1>
              <p className="text-sm text-gray-600">
                Face Recognition Based Attendance Management
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex space-x-8">
            {tabConfig.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? `border-${tab.color}-500 text-${tab.color}-600`
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="space-y-8">
          {activeTab === 'register' && (
            <StudentRegistration onStudentRegistered={handleStudentRegistered} />
          )}
          
          {activeTab === 'track' && (
            <AttendanceTracker students={students} />
          )}
          
          {activeTab === 'reports' && (
            <AttendanceReports />
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-12">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="text-center text-gray-500 text-sm">
            <p>Student Attendance System - Built with React & TypeScript</p>
            <p className="mt-1">
              Registered Students: {students.length} | 
              Total Attendance Records: Available in Reports
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
import React, { useState, useEffect } from 'react';
import { Download, Calendar, BarChart3 } from 'lucide-react';
import { AttendanceRecord } from '../types/student';
import { loadAttendanceRecords, exportToCSV } from '../utils/storage';

export const AttendanceReports: React.FC = () => {
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [filteredRecords, setFilteredRecords] = useState<AttendanceRecord[]>([]);
  const [selectedDate, setSelectedDate] = useState('');

  useEffect(() => {
    const loadedRecords = loadAttendanceRecords();
    setRecords(loadedRecords);
    setFilteredRecords(loadedRecords);
  }, []);

  useEffect(() => {
    if (selectedDate) {
      const filtered = records.filter(record => 
        new Date(record.timestamp).toDateString() === new Date(selectedDate).toDateString()
      );
      setFilteredRecords(filtered);
    } else {
      setFilteredRecords(records);
    }
  }, [selectedDate, records]);

  const handleExport = () => {
    if (filteredRecords.length === 0) {
      alert('No records to export');
      return;
    }
    exportToCSV(filteredRecords);
  };

  const getAttendanceStats = () => {
    const today = new Date().toDateString();
    const todayRecords = records.filter(record => 
      new Date(record.timestamp).toDateString() === today
    );
    
    const uniqueStudents = new Set(records.map(r => r.studentId)).size;
    const totalRecords = records.length;
    
    return {
      todayAttendance: todayRecords.length,
      totalStudents: uniqueStudents,
      totalRecords
    };
  };

  const stats = getAttendanceStats();

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center gap-3 mb-6">
        <BarChart3 className="w-6 h-6 text-purple-600" />
        <h2 className="text-2xl font-semibold text-gray-800">Attendance Reports</h2>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-blue-50 p-4 rounded-lg text-center">
          <div className="text-2xl font-bold text-blue-600">{stats.todayAttendance}</div>
          <div className="text-sm text-blue-700">Today's Attendance</div>
        </div>
        <div className="bg-green-50 p-4 rounded-lg text-center">
          <div className="text-2xl font-bold text-green-600">{stats.totalStudents}</div>
          <div className="text-sm text-green-700">Registered Students</div>
        </div>
        <div className="bg-purple-50 p-4 rounded-lg text-center">
          <div className="text-2xl font-bold text-purple-600">{stats.totalRecords}</div>
          <div className="text-sm text-purple-700">Total Records</div>
        </div>
      </div>

      {/* Filters and Export */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="flex items-center gap-2">
          <Calendar className="w-5 h-5 text-gray-500" />
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          {selectedDate && (
            <button
              onClick={() => setSelectedDate('')}
              className="text-sm text-gray-500 hover:text-gray-700"
            >
              Clear
            </button>
          )}
        </div>
        
        <button
          onClick={handleExport}
          className="bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-md transition-colors flex items-center gap-2"
        >
          <Download className="w-4 h-4" />
          Export CSV
        </button>
      </div>

      {/* Records Table */}
      <div className="overflow-x-auto">
        <table className="w-full border-collapse border border-gray-300">
          <thead>
            <tr className="bg-gray-50">
              <th className="border border-gray-300 px-4 py-2 text-left">Student ID</th>
              <th className="border border-gray-300 px-4 py-2 text-left">Name</th>
              <th className="border border-gray-300 px-4 py-2 text-left">Date</th>
              <th className="border border-gray-300 px-4 py-2 text-left">Time</th>
            </tr>
          </thead>
          <tbody>
            {filteredRecords.length > 0 ? (
              filteredRecords.map((record, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">{record.studentId}</td>
                  <td className="border border-gray-300 px-4 py-2">{record.studentName}</td>
                  <td className="border border-gray-300 px-4 py-2">{record.date}</td>
                  <td className="border border-gray-300 px-4 py-2">{record.time}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={4} className="border border-gray-300 px-4 py-8 text-center text-gray-500">
                  No attendance records found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
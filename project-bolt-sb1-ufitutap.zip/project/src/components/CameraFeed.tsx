import React, { useEffect } from 'react';
import { Camera, CameraOff } from 'lucide-react';
import { useCamera } from '../hooks/useCamera';

interface CameraFeedProps {
  onImageCapture?: (imageData: string) => void;
  isCapturing?: boolean;
}

export const CameraFeed: React.FC<CameraFeedProps> = ({ 
  onImageCapture, 
  isCapturing = false 
}) => {
  const { videoRef, isActive, error, startCamera, stopCamera, captureImage } = useCamera();

  useEffect(() => {
    if (isCapturing && isActive && onImageCapture) {
      const imageData = captureImage();
      if (imageData) {
        onImageCapture(imageData);
      }
    }
  }, [isCapturing, isActive, captureImage, onImageCapture]);

  const handleToggleCamera = () => {
    if (isActive) {
      stopCamera();
    } else {
      startCamera();
    }
  };

  return (
    <div className="relative bg-gray-900 rounded-lg overflow-hidden">
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-red-100 border border-red-300 rounded-lg">
          <p className="text-red-600 text-center p-4">{error}</p>
        </div>
      )}
      
      {!isActive && !error && (
        <div className="aspect-video bg-gray-800 flex items-center justify-center">
          <CameraOff className="w-16 h-16 text-gray-400" />
        </div>
      )}
      
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className={`w-full aspect-video object-cover ${!isActive ? 'hidden' : ''}`}
      />
      
      <div className="absolute top-4 right-4">
        <button
          onClick={handleToggleCamera}
          className={`p-2 rounded-full transition-colors ${
            isActive 
              ? 'bg-red-600 hover:bg-red-700 text-white' 
              : 'bg-blue-600 hover:bg-blue-700 text-white'
          }`}
        >
          {isActive ? <CameraOff className="w-5 h-5" /> : <Camera className="w-5 h-5" />}
        </button>
      </div>
      
      {isActive && (
        <div className="absolute bottom-4 left-4 bg-green-600 text-white px-3 py-1 rounded-full text-sm">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
            Live
          </div>
        </div>
      )}
    </div>
  );
};
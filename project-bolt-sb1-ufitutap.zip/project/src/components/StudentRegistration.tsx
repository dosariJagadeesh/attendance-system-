import React, { useState } from 'react';
import { UserPlus, Save } from 'lucide-react';
import { CameraFeed } from './CameraFeed';
import { Student } from '../types/student';

interface StudentRegistrationProps {
  onStudentRegistered: (student: Student) => void;
}

export const StudentRegistration: React.FC<StudentRegistrationProps> = ({ 
  onStudentRegistered 
}) => {
  const [name, setName] = useState('');
  const [id, setId] = useState('');
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isCapturing, setIsCapturing] = useState(false);

  const handleImageCapture = (imageData: string) => {
    setCapturedImage(imageData);
    setIsCapturing(false);
  };

  const handleRegister = () => {
    if (!name.trim() || !id.trim() || !capturedImage) {
      alert('Please fill all fields and capture an image');
      return;
    }

    const student: Student = {
      id: id.trim(),
      name: name.trim(),
      imageData: capturedImage,
      registrationDate: new Date().toISOString()
    };

    onStudentRegistered(student);
    
    // Reset form
    setName('');
    setId('');
    setCapturedImage(null);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center gap-3 mb-6">
        <UserPlus className="w-6 h-6 text-blue-600" />
        <h2 className="text-2xl font-semibold text-gray-800">Register New Student</h2>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Student ID
            </label>
            <input
              type="text"
              value={id}
              onChange={(e) => setId(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter student ID"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Student Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter student name"
            />
          </div>

          <div className="space-y-2">
            <button
              onClick={() => setIsCapturing(true)}
              disabled={isCapturing}
              className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white py-2 px-4 rounded-md transition-colors"
            >
              {isCapturing ? 'Capturing...' : 'Capture Photo'}
            </button>
            
            {capturedImage && (
              <div className="text-center">
                <p className="text-sm text-green-600 mb-2">✓ Photo captured successfully</p>
                <img 
                  src={capturedImage} 
                  alt="Captured" 
                  className="w-20 h-20 object-cover rounded-full mx-auto border-2 border-green-500"
                />
              </div>
            )}
          </div>

          <button
            onClick={handleRegister}
            disabled={!name.trim() || !id.trim() || !capturedImage}
            className="w-full bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white py-2 px-4 rounded-md transition-colors flex items-center justify-center gap-2"
          >
            <Save className="w-4 h-4" />
            Register Student
          </button>
        </div>

        <div>
          <CameraFeed 
            onImageCapture={handleImageCapture}
            isCapturing={isCapturing}
          />
        </div>
      </div>
    </div>
  );
};
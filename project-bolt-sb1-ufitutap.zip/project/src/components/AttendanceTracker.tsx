import React, { useState, useEffect } from 'react';
import { Users, Clock, CheckCircle } from 'lucide-react';
import { CameraFeed } from './CameraFeed';
import { Student, AttendanceRecord } from '../types/student';
import { hasAttendanceToday, saveAttendanceRecord } from '../utils/storage';

interface AttendanceTrackerProps {
  students: Student[];
}

export const AttendanceTracker: React.FC<AttendanceTrackerProps> = ({ students }) => {
  const [recognitionActive, setRecognitionActive] = useState(false);
  const [lastRecognition, setLastRecognition] = useState<string | null>(null);
  const [todayAttendance, setTodayAttendance] = useState<string[]>([]);

  useEffect(() => {
    // Update today's attendance list
    const attendedToday = students
      .filter(student => hasAttendanceToday(student.id))
      .map(student => student.id);
    setTodayAttendance(attendedToday);
  }, [students]);

  // Simulate face recognition (in a real implementation, this would use actual face recognition)
  const simulateRecognition = () => {
    if (students.length === 0) return;
    
    // For demo purposes, randomly select a student
    const randomStudent = students[Math.floor(Math.random() * students.length)];
    
    if (hasAttendanceToday(randomStudent.id)) {
      setLastRecognition(`${randomStudent.name} already marked today`);
      return;
    }

    const now = new Date();
    const record: AttendanceRecord = {
      studentId: randomStudent.id,
      studentName: randomStudent.name,
      date: now.toDateString(),
      time: now.toLocaleTimeString(),
      timestamp: now.getTime()
    };

    saveAttendanceRecord(record);
    setLastRecognition(`✓ ${randomStudent.name} marked present`);
    setTodayAttendance(prev => [...prev, randomStudent.id]);
  };

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (recognitionActive) {
      interval = setInterval(simulateRecognition, 5000); // Simulate recognition every 5 seconds
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [recognitionActive, students, todayAttendance]);

  const handleToggleRecognition = () => {
    setRecognitionActive(!recognitionActive);
    if (!recognitionActive) {
      setLastRecognition(null);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center gap-3 mb-6">
        <Users className="w-6 h-6 text-green-600" />
        <h2 className="text-2xl font-semibold text-gray-800">Attendance Tracking</h2>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <CameraFeed />
          
          <div className="mt-4 space-y-3">
            <button
              onClick={handleToggleRecognition}
              className={`w-full py-3 px-4 rounded-md transition-colors flex items-center justify-center gap-2 ${
                recognitionActive
                  ? 'bg-red-600 hover:bg-red-700 text-white'
                  : 'bg-green-600 hover:bg-green-700 text-white'
              }`}
            >
              <Clock className="w-5 h-5" />
              {recognitionActive ? 'Stop Tracking' : 'Start Tracking'}
            </button>

            {recognitionActive && (
              <div className="bg-blue-50 border border-blue-200 rounded-md p-3">
                <p className="text-blue-700 text-center">
                  🔍 Face recognition active...
                </p>
              </div>
            )}

            {lastRecognition && (
              <div className="bg-green-50 border border-green-200 rounded-md p-3">
                <p className="text-green-700 text-center">
                  {lastRecognition}
                </p>
              </div>
            )}
          </div>
        </div>

        <div>
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            Today's Attendance ({todayAttendance.length}/{students.length})
          </h3>
          
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {students.map(student => {
              const isPresent = todayAttendance.includes(student.id);
              
              return (
                <div
                  key={student.id}
                  className={`flex items-center gap-3 p-3 rounded-md border ${
                    isPresent
                      ? 'bg-green-50 border-green-200'
                      : 'bg-gray-50 border-gray-200'
                  }`}
                >
                  <img
                    src={student.imageData}
                    alt={student.name}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <p className="font-medium text-gray-800">{student.name}</p>
                    <p className="text-sm text-gray-500">ID: {student.id}</p>
                  </div>
                  {isPresent && (
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  )}
                </div>
              );
            })}
            
            {students.length === 0 && (
              <p className="text-gray-500 text-center py-4">
                No students registered yet
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
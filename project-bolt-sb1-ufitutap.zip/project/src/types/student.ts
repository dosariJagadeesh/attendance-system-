export interface Student {
  id: string;
  name: string;
  imageData: string;
  registrationDate: string;
}

export interface AttendanceRecord {
  studentId: string;
  studentName: string;
  date: string;
  time: string;
  timestamp: number;
}

export interface CameraConstraints {
  video: {
    width: { ideal: number };
    height: { ideal: number };
    facingMode: string;
  };
}